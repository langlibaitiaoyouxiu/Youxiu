<?php
namespace backend\models;

use yii\db\ActiveRecord;

class Admin extends ActiveRecord{
	
}