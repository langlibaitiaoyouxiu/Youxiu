<?php
return [
   
	"url" =>[

			"admin" =>'http://gameadmin.net',
			"home" => 'http://gameadmin.net'
	]
];
