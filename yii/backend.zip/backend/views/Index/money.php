﻿
					<div class="page-content">
						<div class="page-header">
						</div><!-- /.page-header -->

						<div class="row">
								<div class="text-center" style=" font-size:12px;">        
										<div>
											<ul class="accordion-style1">
											<li class="li-new-mail text-left" >
											<h3>    1、通过微信扫描左边二维码自动充值(支付成功后3秒刷新页面即可)
											  </h3>
												</li>
											<li class="text-left">
												<h3>2、通过转账到支付宝13588461234，备注填手机号自动充值
												<h3>
												</li>
											
											<li class="text-left">
											  <h3>  3、10元起充，不要转1元以下零头，如果忘记填手机号，使用交易号充值
												</h3></li>
											<li class="text-left">
											   <h3> 4、	交易号(订单号):  &nbsp;&nbsp;&nbsp;  <input  type="text" class="input-elm" />
											   &nbsp;&nbsp;&nbsp;&nbsp;
											   <button class="btn btn-info">充值</button>
											   &nbsp;&nbsp;&nbsp;&nbsp;
												<button class="btn btn-info">清空</button>	</h3>
												</li>
												<li class="text-left"><h3>
											5、通过网银、财富通、ATM取款机、银行柜台转银行卡 </h3>
												   <h5 style="color:#F18740">
												   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;①工行:6222 0212 0204 0069 800(杭州市城东支行)<br></h5>
												  <h5 style="color:#F18740"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;②建行:6217 0015 4000 0913 242(杭州市竞舟路支行)</h5>
										   </li>
										   <li class="text-left">
										  <h3> 6、姓名:赵守超 微信:13567181234 电话:13567181234、13588461234</h3>
										   </li>
											</ul>
									</div>
								</div>




								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div><!-- /.main-content -->

				