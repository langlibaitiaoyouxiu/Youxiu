﻿
				<div class="main-content">
					<div class="breadcrumbs" id="breadcrumbs">
						<script type="text/javascript">
							try{ace.settings.check('breadcrumbs' , 'fixed')}catch(e){}
						</script>

						<ul class="breadcrumb">
							<li>
								<i class="icon-home home-icon"></i>
								<a href="#">首页</a>
							</li>
							<li class="active">账户管理</li>
                            <li class="active">充值记录</li>
						</ul><!-- .breadcrumb -->
					</div>

					<div class="page-content">


								<div class="row">
									<div class="col-xs-12">
										<div class="table-responsive">
											<table id="sample-table-1" class="table table-striped table-bordered table-hover">
												<thead>
													<tr>
														<th class="center">
															<label>
																<input type="checkbox" class="ace" />
																<span class="lbl"></span>
															</label>
														</th>
														<th>编号</th>
														<th>交易日期</th>
														<th>交易类型</th>
														<th>交易金额</th>
														<th>交易状态</th>
													</tr>
												</thead>

												<tbody>
													<tr>
														<td class="center">
															<label>
																<input type="checkbox" class="ace" />
																<span class="lbl"></span>
															</label>
														</td>

														<td>1</td>
														<td>2015-10-06 19:17:09</td>
														<td>账号充值</td>
														<td>10.00</td>
														<td>交易成功</td>
													</tr>
													
													<tr>
														<td class="center">
															<label>
																<input type="checkbox" class="ace" />
																<span class="lbl"></span>
															</label>
														</td>

														<td>1</td>
														<td>2015-10-02 19:17:09</td>
														<td>账号充值</td>
														<td>100.00</td>
														<td>交易成功</td>
													</tr>
													
													<tr>
														<td class="center">
															<label>
																<input type="checkbox" class="ace" />
																<span class="lbl"></span>
															</label>
														</td>

														<td>1</td>
														<td>2015-11-06 19:17:09</td>
														<td>账号充值</td>
														<td>10.00</td>
														<td style="color:red;">交易失败</td>
													</tr>


													
												</tbody>
											</table>
										</div><!-- /.table-responsive -->
									</div><!-- /span -->
								</div><!-- /row -->
					</div><!-- /.page-content -->
				</div><!-- /.main-content -->

				