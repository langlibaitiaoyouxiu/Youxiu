﻿
					<div class="page-content">
							<div class="row">
							

									<div class="col-xs-12">

									
									
										<div class="table-responsive">
											<table id="sample-table-1" class="table table-striped table-bordered table-hover">
												<thead>
													<tr>
														<th class="center">
															<label>
																<input type="checkbox" class="ace" />
																<span class="lbl"></span>
															</label>
														</th>
														<th>编号</th>
														<th>网站</th>
														<th>姓名</th>
														<th>用户名</th>
														<th>类型</th>
														<th>到期时间</th>
														<th>操作</th>
													</tr>
												</thead>

												<tbody>
													<tr>
														<td class="center">
															<label>
																<input type="checkbox" class="ace" />
																<span class="lbl"></span>
															</label>
														</td>

														<td>A001</td>
														<td>58同城</td>
														<td>张三</td>
														<td>zhangsan</td>
														<td>非包月</td>
														<td>20/06/2010</td>
														<td>
														<button class="btn">编辑</button>
														<button class="btn btn-danger">删除</button>
														</td>

													</tr>
													<tr>
														<td class="center">
															<label>
																<input type="checkbox" class="ace" />
																<span class="lbl"></span>
															</label>
														</td>

														<td>A002</td>
														<td>58同城</td>
														<td>张三</td>
														<td>zhangsan</td>
														<td>非包月</td>
														<td>20/06/2010</td>
														<td>
														<button class="btn">编辑</button>
														<button class="btn btn-danger">删除</button>
														</td>

													</tr>										

													
												</tbody>
											</table>
										</div><!-- /.table-responsive -->
									</div><!-- /span -->
								</div><!-- /row -->

					</div><!-- /.page-content -->
				</div><!-- /.main-content -->

				