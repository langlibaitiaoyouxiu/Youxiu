﻿

					<div class="page-content">


								<div class="row">
									<div class="col-xs-12">
										<div class="table-responsive">
											<table id="sample-table-1" class="table table-striped table-bordered table-hover">
												<thead>
													<tr>
														<th class="center">
															<label>
																<input type="checkbox" class="ace" />
																<span class="lbl"></span>
															</label>
														</th>
														<th>房源编号</th>
														<th>房源简介</th>
														<th>房型</th>
														<th>发布时间</th>
													</tr>
												</thead>

												<tbody>
													<tr>
														<td class="center">
															<label>
																<input type="checkbox" class="ace" />
																<span class="lbl"></span>
															</label>
														</td>

														<td>A001</td>
														<td>博山小区，内环宜居黄金地段，全明户型，房型正气，投资居家首选</td>
														<td>博山小区 63平，2室1厅，4/6层</td>
														<td>20/06/2010</td>

													</tr>
													
																										<tr>
														<td class="center">
															<label>
																<input type="checkbox" class="ace" />
																<span class="lbl"></span>
															</label>
														</td>

														<td>A001</td>
														<td>博山小区，内环宜居黄金地段，全明户型，房型正气，投资居家首选</td>
														<td>博山小区 63平，2室1厅，4/6层</td>
														<td>20/06/2010</td>

													</tr>

													
												</tbody>
											</table>
										</div><!-- /.table-responsive -->
									</div><!-- /span -->
								</div><!-- /row -->
					</div><!-- /.page-content -->
				</div><!-- /.main-content -->
