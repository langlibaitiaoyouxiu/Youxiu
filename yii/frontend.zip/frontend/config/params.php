<?php
return [
    "url" => [
    	"home" => "http://game.net",
		'admin' => "http://game.net"
    ]
];
