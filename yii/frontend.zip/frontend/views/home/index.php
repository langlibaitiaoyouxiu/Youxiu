<?php 
use common\services\UrlServices;
 ?>
  <link rel="stylesheet" type="text/css" href="<?=UrlServices::HomeUrl('/layui/css/layui.css')  ?>">
 <script type="text/javascript" src="<?=UrlServices::HomeUrl('/layui/layui.js')  ?>"></script>
 <script type="text/javascript" src="<?=UrlServices::HomeUrl('/layui/layui.all.js')  ?>"></script>
 <script type="text/javascript" src="<?=UrlServices::HomeUrl('/js/jquery-1.11.3.js')  ?>"></script>
<div class="p_pop h_pop" id="mn_userapp_menu" style="display: none"></div><div id="mu" class="cl">
</div>
</div>
<script src="<?=UrlServices::HomeUrl('/js/paradise-6.js')  ?>" type="text/javascript"></script>

<div id="wp" class="wp">
<div id="pt" class="bm cl">
<div class="y">
<div id="an">
<dl class="cl">

<dd>
</dd>
</dl>
</div>
<script type="text/javascript">
announcement();
</script>
</div>
<div class="z">
<a href="./" class="nvhm" title="首页">Game Paradise</a><em>&raquo;</em><a href="/">首页</a></div>
<div class="z"></div>
</div>



<style id="diy_style" type="text/css"></style>

<div class="wic_ng cl" >
<div class="wic_ng_left"  >
    	<div class="wic_ng_left_t cl"  >
        	<div class="wic_ng_slide" >
                <!--[diy=diywic_ng_slide]--><div id="diywic_ng_slide" class="area"><div id="framei4R74e" class="frame move-span cl frame-1"><div id="framei4R74e_left" class="column frame-1-c"><div id="framei4R74e_left_temp" class="move-span temp"></div><div id="portal_block_81" class="block move-span"><div id="portal_block_81_content" class="dxb_bc"><div class="bd">
<ul>

    <li>
		<div class="pic">
        <img src="<?=UrlServices::AdminUrl('/images/cjzc.jpg'); ?>" width="448" height="253" /></div>
        <div class="info">
            由腾讯和PUBG联合开发的吃鸡手游《绝地求生：刺激战场》正式公布。 [2]  据介绍，《绝地求生：刺激战场》是绝地求生正版战斗特训手游，由腾讯光子工作室群超过200人团队研发
        </div>
	
	</li>
      <li>
        <div class="pic">
        <img src="<?=UrlServices::AdminUrl('/images/dwrg1.jpg'); ?>" width="448" height="253" /></div>
        <div class="info">
           极品飞车1发行于1995年，是专业汽车杂志RoadTrack和EA的合作产物。游戏中收录了当时欧美日三地的一流跑车。起初发行于一台名叫3DO的游戏主机，直至该
《极品飞车》游戏截图
《极品飞车》游戏截图(20张)
 主机退出市场，才被移植至PC。因为RoadTrack杂志的赛车数据十分专业，导致不同车型之间的速度差别十分明显，较差车型在游戏中基本毫无竞争力，因此游戏平衡性对于本作来说算是比较糟糕。游戏中赛车换档时，会有一个档杆动作。1代的安装界面是历代中最优秀的
        </div>
    
    </li>
    <li>
        <div class="pic">
        <img src="<?=UrlServices::AdminUrl('/images/dwrg3.jpg'); ?>" width="448" height="253" /></div>
        <div class="info">
        《第五人格》 [1]  是由网易开发的非对称性对抗竞技类（Asymmetrical Battle Arena）手机游戏， [2]  游戏于2018年4月12日开启公测。 [3-4] 
《第五人格》采用了蒂姆-伯顿式的哥特画风，人物采用线缝制的布偶设定。玩家将分别扮演追、逃双方，前者在攻击上有极大的先天优势，拥有强大的“搜索、追逐”能力，要阻止并抓住所有人才能获胜；而后者虽然弱小，但有着人数和资源优势，依靠有利的复杂地图进行潜伏、分工合作，并有一定的反制措施，只要有一人完成目标即宣告胜利。
        </div>
    
    </li>
    <li>
        <div class="pic">
        <img src="<?=UrlServices::AdminUrl('/images/dwrg4.jpg'); ?>" width="448" height="253" /></div>
        <div class="info">
    《植物大战僵尸》是由PopCap Games开发的一款益智策略类单机游戏，于2009年5月5日发售。
玩家通过武装多种植物切换不同的功能，快速有效地把僵尸阻挡在入侵的道路上。不同的敌人，不同的玩法构成五种不同的游戏模式，加之黑夜、浓雾以及泳池之类的障碍增加了游戏挑战性。
        </div>
    
    </li>
    <li>
        <div class="pic">
        <img src="<?=UrlServices::AdminUrl('/images/dwrg2.jpg'); ?>" width="448" height="253" /></div>
        <div class="info">
        《第五人格》 [1]  是由网易开发的非对称性对抗竞技类（Asymmetrical Battle Arena）手机游戏， [2]  游戏于2018年4月12日开启公测。 [3-4] 
《第五人格》采用了蒂姆-伯顿式的哥特画风，人物采用线缝制的布偶设定。玩家将分别扮演追、逃双方，前者在攻击上有极大的先天优势，拥有强大的“搜索、追逐”能力，要阻止并抓住所有人才能获胜；而后者虽然弱小，但有着人数和资源优势，依靠有利的复杂地图进行潜伏、分工合作，并有一定的反制措施，只要有一人完成目标即宣告胜利。
        </div>
    
    </li>
   </ul>
</div>
<div class="hd">
<ul>
    <li>1</li><li>2</li><li>3</li><li>4</li><li>5</li></ul>
</div>
<div class="slide-nav">
<a href="javascript:void(0)" class="prev"></a>
<a href="javascript:void(0)" class="next"></a>
</div></div></div></div></div></div><!--[/diy]-->
            </div>

            <div class="wic_ng_focus">
            	<div class="wic_ng_headline">
                	<div class="hltit cl">
                    	<h2>游戏攻略</h2>
                    </div>
                    <div class="wic_ng_headline_c">
                    	<!--[diy=diywic_ng_headline]--><div id="diywic_ng_headline" class="area"><div id="frameVLE6i3" class="frame move-span cl frame-1"><div id="frameVLE6i3_left" class="column frame-1-c"><div id="frameVLE6i3_left_temp" class="move-span temp"></div><div id="portal_block_82" class="block move-span">
<div id="portal_block_82_content" class="dxb_bc">
<ul>
    <li>
		<h3><a href="<?=UrlServices::HomeUrl('strateg')  ?>?id=<?=$desc[0]['strateg_id']  ?>" target="_blank"><?=$desc[0]['strateg_name']  ?></a></h3>
		<p><?=$desc[1]['strateg_name']  ?></p>
	</li></ul>
</div></div>
</div></div></div><!--[/diy]-->
                    </div>

                </div>


                <div class="wic_ng_focus_list">
<div id="diywic_ng_focus_list" class="area">
    <div id="frameL3vU2y" class="frame move-span cl frame-1">
        <div id="frameL3vU2y_left" class="column frame-1-c">
            <div id="frameL3vU2y_left_temp" class="move-span temp"></div>
                <div id="portal_block_83" class="block move-span">
                     <div id="portal_block_83_content" class="dxb_bc">

<ul>
    <?php foreach ($desc as $key => $value): ?>
        
    <li class="cl">
        <a href="<?=UrlServices::HomeUrl('strateg')  ?>?id=<?=$value['strateg_id']  ?>" target="_blank"><?=$value['strateg_name']  ?></a><span>04-22</span></li>
    <?php endforeach ?>
 
</ul>
</div></div></div></div></div><!--[/diy]-->
                </div>
            </div>
        </div>

        <div class="wic_ng_left_b">
        	<div class="wic_ng_tablist">
                <div class="wic_ng_tablist_wrap">
                    <div class="tablist_t cl">

                        <ul>
                          
                     
                           <li >第五人格</li>
                           <li>王者荣耀</li>
                      
                        </ul>
                    </div>
                    <div class="tablist_c" style="height: 155px;">

                        <div class="tablist_box" style=" display:block;" >
                        	<div class="tablist_pic cl">
                            	<!--[diy=diytablist_pic1]-->
                    <div id="diytablist_pic1" class="area">
                        <div id="frameotvcAU" class="frame move-span cl frame-1">
                            <div id="frameotvcAU_left" class="column frame-1-c">
                            <div id="frameotvcAU_left_temp" class="move-span temp"></div>
                                <div id="portal_block_84" class="block move-span">
                                    <div id="portal_block_84_content" class="dxb_bc">

</div></div></div></div></div><!--[/diy]-->
                            </div>

        <div class="tablist_txt" >
            <div id="diytablist_txt2" class="area">
        <div id="framecN2cSw" class="frame move-span cl frame-1">
        <div id="framecN2cSw_left" class="column frame-1-c">
            <div id="framecN2cSw_left_temp" class="move-span temp"></div>
            <div id="portal_block_88" class="block move-span">
                                            <div id="portal_block_88_content" class="dxb_bc">
<ul>
        <?php foreach ($list as $key => $value): 

            if($value['game_id'] == 1){
        ?>
 <li class="cl"><a href="<?=UrlServices::HomeUrl('strateg')  ?>?id=<?=$value['strateg_id']  ?>" target="_blank" class="cate">王者荣耀</a><a href="<?=UrlServices::HomeUrl('strateg')  ?>?id=<?=$value['strateg_id']  ?>" target="_blank" class="tit"><?=$value['strateg_name']  ?></a><span>04-22</span></li>
            
        
   

<?php } endforeach ?>



   

</ul>
</div></div></div></div></div>
                            </div>  



                        </div>
                        <div class="tablist_box">
                            <div class="tablist_txt">
                            	<!--[diy=diytablist_txt3]-->
    <div id="diytablist_txt3" class="area"><div id="framex9XS94" class="frame move-span cl frame-1"><div id="framex9XS94_left" class="column frame-1-c"><div id="framex9XS94_left_temp" class="move-span temp"></div><div id="portal_block_90" class="block move-span"><div id="portal_block_90_content" class="dxb_bc">
<ul>
   <?php foreach ($list as $key => $value): 

    if($value['game_id'] == 2){
        ?>
 <li class="cl"><a href="<?=UrlServices::HomeUrl('strateg')  ?>?id=<?=$value['strateg_id']  ?>" target="_blank" class="cate">QQ飞车手游</a><a href="<?=UrlServices::HomeUrl('strateg')  ?>?id=<?=$value['strateg_id']  ?>" target="_blank" class="tit"><?=$value['strateg_name']  ?></a><span>04-22</span></li>
            
        
   

<?php } endforeach ?>

</ul>
</div></div></div></div></div><!--[/diy]-->
                            </div>
                        </div>



                        <div class="tablist_box">
                        	<div class="tablist_pic cl">
                            	<!--[diy=diytablist_pic4]--><div id="diytablist_pic4" class="area"><div id="framesASu41" class="frame move-span cl frame-1"><div id="framesASu41_left" class="column frame-1-c"><div id="framesASu41_left_temp" class="move-span temp"></div><div id="portal_block_91" class="block move-span"><div id="portal_block_91_content" class="dxb_bc">
</div></div></div></div></div><!--[/diy]-->
                            </div>
                            <div class="tablist_txt">
                            	<!--[diy=diytablist_txt4]--><div id="diytablist_txt4" class="area"><div id="frameg471It" class="frame move-span cl frame-1"><div id="frameg471It_left" class="column frame-1-c"><div id="frameg471It_left_temp" class="move-span temp"></div><div id="portal_block_92" class="block move-span"><div id="portal_block_92_content" class="dxb_bc">
<ul>


      <?php foreach ($list as $key => $value): 
    if($value['game_id'] == 3){ ?>
        
 <li class="cl"><a href="<?=UrlServices::HomeUrl('strateg')  ?>?id=<?=$value['strateg_id']  ?>" target="_blank" class="cate">绝地求生刺激战场</a><a href="<?=UrlServices::HomeUrl('strateg')  ?>?id=<?=$value['strateg_id']  ?>" target="_blank" class="tit"><?=$value['strateg_name']  ?></a><span>04-22</span></li>
            
        
   

<?php } 
endforeach ?>



</ul>
</div></div></div></div></div><!--[/diy]-->
                            </div>  
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="wic_ng_right">
    	<div class="wic_ng_user_rank">
        	<div class="wic_ng_user_rank_t cl">
            	<ul>
                	<li class="on">lol大神</li>
                    <li class="odd">顶级打手</li>
                </ul>
            </div>
            <!-- 展示代练大神 -->
            <div class="wic_ng_user_rank_c">
            	<div class="wic_ng_user_rank_box" style=" display:block;">
                	<!--[diy=diywic_ng_user_rank1]--><div id="diywic_ng_user_rank1" class="area"><div id="frameCAaiXb" class="frame move-span cl frame-1"><div id="frameCAaiXb_left" class="column frame-1-c"><div id="frameCAaiXb_left_temp" class="move-span temp"></div><div id="portal_block_93" class="block move-span"><div id="portal_block_93_content" class="dxb_bc"><ul>

          <?php foreach ($user as $key => $value): ?>
                        <li class="cl">
                        <div class="wavt">
                            <?php if($value['user_img'] == ''){ ?>
                            <img src="<?=UrlServices::HomeUrl('/images/touxiang.gif')  ?>" width="60" height="60" />
                            <?php } else { ?>
                           <img src="<?=UrlServices::HomeUrl('/').$value['user_img']  ?>" width="60" height="60" />

                            <?php }?>
                        </div>
                        <div class="info">
                        <h3><?=$value['user_name']  ?></h3>
                        <p></p>
                        </div>
                        </li> 
                    <?php endforeach ?>

   

</ul></div></div></div></div></div><!--[/diy]-->
                </div>

                <div class="wic_ng_user_rank_box">
                	<!--[diy=diywic_ng_user_rank2]--><div id="diywic_ng_user_rank2" class="area"><div id="framedTICiz" class="frame move-span cl frame-1"><div id="framedTICiz_left" class="column frame-1-c"><div id="framedTICiz_left_temp" class="move-span temp"></div><div id="portal_block_94" class="block move-span"><div id="portal_block_94_content" class="dxb_bc"><ul>

                    <?php foreach ($user as $key => $value): ?>
                        <li class="cl">
                        <div class="wavt">
                            <?php if($value['user_img'] == ''){ ?>
                            <img src="<?=UrlServices::HomeUrl('/images/touxiang.gif')  ?>" width="60" height="60" />
                            <?php } else { ?>
                           <img src="<?=UrlServices::HomeUrl('/').$value['user_img']  ?>" width="60" height="60" />

                            <?php }?>
                        </div>
                        <div class="info">
                        <h3><?=$value['user_name']  ?></h3>
                        <p></p>
                        </div>
                        </li> 
                    <?php endforeach ?>
   

   
</ul></div></div></div></div></div><!--[/diy]-->
                </div>
            </div>
            <!-- 代练大神展示结束 -->
       
        </div>
    </div> 
</div>
<script type="text/javascript">
jq(".tablist_t li").each(function(s){
jq(this).hover(function(){
jq(this).addClass("on").siblings().removeClass("on");
jq(".tablist_c .tablist_box").eq(s).show().siblings().hide();
})
})
jq(".wic_ng_user_rank_t li").each(function(s){
jq(this).hover(function(){
jq(this).addClass("on").siblings().removeClass("on");
jq(".wic_ng_user_rank_c .wic_ng_user_rank_box").eq(s).show().siblings().hide();
})
})
</script>

<script type="text/javascript">
jq(".wic_ng_slide").slide({ mainCell:".bd ul",titCell:".hd li",delayTime:600,interTime:5000,triggerTime:50,effect:"fade",autoPlay:true,});
jq(".tablist_news").slide({mainCell:".bd ul",autoPlay:true,effect:"leftMarquee",interTime:30,trigger:"click"});
</script>
<div class="wp">
<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
</div>

<!--
<div class="bbscount mb10 cl">
<ul>
    	<li class="today  cl">
        	<div class="bctit">今日</div> 
            <div class="bcnum">0</div>
        </li>
        <li class="yesterday  cl">
        	<div class="bctit">昨日</div> 
            <div class="bcnum">0</div>
        </li>
        <li class="posts  cl">
        	<div class="bctit">帖子</div> 
            <div class="bcnum">3981</div>
        </li>
        <li class="member  cl">
        	<div class="bctit">会员</div> 
            <div class="bcnum">7255</div>
        </li>
    </ul>
    <div class="y mt10">
        <a href="http://www.dailianzj.com/forum.php?mod=guide&amp;view=new" title="最新回复" class="xi2">最新回复</a><span class="pipe">|</span>欢迎新会员: <em><a href="http://dailianzj.com/home.php?mod=space&amp;username=qq642283796" target="_blank" class="xi2">qq642283796</a></em>    </div>
</div>
-->
<div id="ct" class="wp cl">
<!--[diy=diy_chart]--><div id="diy_chart" class="area"></div><!--[/diy]-->
<div class="mn">
<div class="fl bm">




<!-- 交流区 -->
<div class="bm bmw  flg cl">
<div class="bm_h cl">
<span class="o">
</span>
<span class="y"></span><h2><a href="http://www.dailianzj.com/forum.php?gid=1" style="">热门游戏</a></h2>
</div>
<div id="category_1" class="bm_c" style="">
<table cellspacing="0" cellpadding="0" class="fl_tb">
<tr>
    <?php foreach ($hot as $key => $value): ?>
        
    <td class="fl_g" width="32.9%">
<div class="fl_icn_g" style="width: 81px;">
 <a href="<?=UrlServices::HomeUrl('details');?>?id=<?=$value['game_id']  ?>"><img src="<?=UrlServices::HomeUrl('/').$value['mai_ming']  ?>" align="left" alt=""  style='width:80px;height: 80px;'/></a></div>
<dl style="margin-left: 81px;">
<dt> <a href="<?=UrlServices::HomeUrl('details');?>?id=<?=$value['game_id']  ?>"><?=$value['game_name']  ?></a></dt>

<dd></dd><dd>
</dd>
</dl>
<p><em><?= mb_substr($value['desc_ribe'],0,30,"utf-8")."......"  ?></em> <em></em></p>
</td>
    <?php endforeach ?>

</tr>
</table>
</div>
</div>

<!-- 学习区 -->
<div class="bm bmw  flg cl">
<div class="bm_h cl">
<span class="o">

</span>
<span class="y"></span><h2><a href="http://www.dailianzj.com/forum.php?gid=52" style="">新品游戏</a></h2>
</div>
<div id="category_52" class="bm_c" style="">
<table cellspacing="0" cellpadding="0" class="fl_tb">
<tr>
    <?php foreach ($new as $key => $value): ?>
        
    <td class="fl_g" width="32.9%">
<div class="fl_icn_g" style="width: 81px;">
 <a href="<?=UrlServices::HomeUrl('details');?>?id=<?=$value['game_id']  ?>"><img src="<?=UrlServices::HomeUrl('/').$value['mai_ming']  ?>" align="left" alt=""  style='width:80px;height: 80px;'/></a></div>
<dl style="margin-left: 81px;">
<dt> <a href="<?=UrlServices::HomeUrl('details');?>?id=<?=$value['game_id']  ?>"><?=$value['game_name']  ?></a></dt>
<dd></dd><dd>

</dd>
</dl>
<p><em><?= mb_substr($value['desc_ribe'],0,30,"utf-8")."......"  ?></em> <em></em></p>
</td>
    <?php endforeach ?>
</tr>
</table>
</div>
</div>

<!-- end -->


</div>

<div class="wp mtn">
<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
</div>




</div>

</div>

	</div>


