<?php
use common\services\UrlServices;
 ?>

<div class="p_pop h_pop" id="mn_userapp_menu" style="display: none"></div><div id="mu" class="cl">
</div>
</div>
<script src="template/wic_simple/static/js/nv.js" type="text/javascript"></script>

<div id="wp" class="wp">
<div id="pt" class="bm cl">
<div class="y">
<div id="an">
<dl class="cl">

<dd>
</dd>
</dl>
</div>
<script type="text/javascript">announcement();</script>
</div>
<div class="z">
<a href="./" class="nvhm" title="首页">Game Paradise</a><em>&raquo;</em><a href="/">关于我们</a></div>
<div class="z"></div>
</div>


<style id="diy_style" type="text/css"></style>
<script type="text/javascript">
jq(".tablist_t li").each(function(s){
jq(this).hover(function(){
jq(this).addClass("on").siblings().removeClass("on");
jq(".tablist_c .tablist_box").eq(s).show().siblings().hide();
})
})
jq(".wic_ng_user_rank_t li").each(function(s){
jq(this).hover(function(){
jq(this).addClass("on").siblings().removeClass("on");
jq(".wic_ng_user_rank_c .wic_ng_user_rank_box").eq(s).show().siblings().hide();
})
})
</script>

<script type="text/javascript">
jq(".wic_ng_slide").slide({ mainCell:".bd ul",titCell:".hd li",delayTime:600,interTime:5000,triggerTime:50,effect:"fade",autoPlay:true,});
jq(".tablist_news").slide({mainCell:".bd ul",autoPlay:true,effect:"leftMarquee",interTime:30,trigger:"click"});
</script>
<div class="wp">
<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
</div>


<div id="ct" class="wp cl">
<!--[diy=diy_chart]--><div id="diy_chart" class="area"></div><!--[/diy]-->
<div class="mn">
<div class="fl bm">


<!-- 代练区Star -->
<div class="bm bmw  flg cl">
<div class="bm_h cl">
<span class="o">
<img id="category_38_img" src="static/image/common/collapsed_no.gif" title="收起/展开" alt="收起/展开" onclick="toggle_collapse('category_38');" />
</span>
<span class="y"><a href="http://dailianzj.com/home.php?mod=space&username=%D6%AE%BC%D2%C0%CF%CD%F5" class="notabs" c="1"></a></span><h2><a href="#" style="">关于我们</a></h2>
</div>
<div id="category_38" class="bm_c" style="">
    <center>
     <div cellspacing="0" cellpadding="0" class="fl_tb" style="margin-top: 30px;">
        <tr>
            
            <td class="fl_g" width="32.9%">
                <div class="fl_icn_g" style="width: 81px;">
                                </div>
              
                
           <h2 style="font-size: 20px">我们坐落于北京市海淀区，第二工作</h2><br/>
            <h2 style="font-size: 20px">室我们的宗旨是省心省力顾客就是上</h2><br/>
            <h2 style="font-size: 20px">帝，我们会用我们的的服务质量, 让</h2><br/>
            <h2 style="font-size: 20px">客户感到无比的亲切如果对我们的网</h2><br/>
            <h2 style="font-size: 20px">站有任何的建议或者意见。都可以发送官方邮箱</h2><br/>
           
                   
                
                   
            <font color="#5f9ea0" style="font-size: 16px;">联系热线    ：010-1652659</font><br/>
            <font color="#5f9ea0" style="font-size: 16px;">联系电话    ：19855655555</font><br/>
            <font color="#5f9ea0" style="font-size: 16px;">联系的邮箱    ：90680099@qq.com</font><br/>
            <font color="#5f9ea0" style="font-size: 16px;">您如果有宝贵的意见请通过以上联系方式联系我们                  
               
             
            </td>
            
        </tr>
        </div>   
    </center>
</div>

</div>
    
</div>

<div class="wp mtn">
<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
</div>




</div>

</div>

  </div>

<script type='text/javascript' src='<?=UrlServices::HomeUrl('/')  ?>layui\layui.js'></script>
<script type='text/javascript' src='<?=UrlServices::HomeUrl('/')  ?>layui\layui.all.js'></script>
<script type="text/javascript">

</script>

